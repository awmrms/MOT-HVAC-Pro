# MOT HVAC Pro v3

Aplikasi Android preliminary engineering untuk Modular Operating Theatre / ruang operasi.

## Fitur v3
- Dashboard desain HVAC berbasis input aktual.
- Logo PT Mandiri Pratama Cemerlang.
- Perhitungan volume, supply airflow, fresh air, cooling load, kapasitas TR dan BTU/h.
- Qualification & class: ISO, pressure relationship, ACH, fresh air, safety factor.
- Dashboard RAB/RAP dengan item HVAC, Qty, harga satuan, subtotal, discount, overhead/markup, PPN dan total.
- Template item AHU/FCU, HEPA, ducting, diffuser/LAF, insulasi, TAB & commissioning.
- Historis proyek tersimpan lokal: Edit, PDF, Hapus.
- Print / Save as PDF mengikuti data yang sedang diinput dan tabel RAB/RAP.

## Catatan
Harga satuan RAB/RAP harus diisi berdasarkan quotation/vendor atau analisa harga proyek. Perhitungan HVAC bersifat preliminary dan harus diverifikasi engineer serta standar/peraturan yang berlaku pada tanggal proyek.
