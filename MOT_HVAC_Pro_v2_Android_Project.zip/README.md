# MOT HVAC Pro v2
Dashboard-style Android app for preliminary HVAC calculations for Modular Operating Theatre / operating rooms.

## New in v2
- Dashboard inspired by engineering calculation sheet
- Project/room information
- Airflow, fresh-air, ACH and cooling-load cards
- Supply/return/exhaust guidance
- Qualification & cleanliness section
- Psychrometric-style visual panel
- **PRINT / SIMPAN PDF** button using Android's native print service; on the Android print screen choose **Save as PDF**
- Responsive layout for phone screens

## Build
The GitHub Actions workflow can build a debug APK. The APK artifact is `app-debug.apk`.

## Engineering note
This application is a preliminary engineering calculator. Final design must be verified by the responsible HVAC/MEP engineer against current Indonesian regulations/standards, hospital requirements, detailed psychrometric and heat-load calculations, equipment selections, TAB and commissioning measurements.
