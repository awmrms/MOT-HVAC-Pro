# MOT HVAC Pro
Kalkulator preliminary HVAC Modular Operating Theatre berbasis WebView/PWA.

## Fitur
- Dimensi ruang, volume, ACH occupied/unoccupied
- Fresh air ACH
- Suhu/RH indoor-outdoor
- Estimasi airflow dan beban pendinginan
- Pemeriksaan parameter desain ruang operasi minor
- Cetak ke PDF dari browser

## APK
Project ini siap dibuka di Android Studio dan dapat dibuild menjadi APK.
Alternatif: push ke GitHub lalu jalankan workflow `.github/workflows/build-apk.yml`.

## Catatan engineering
Aplikasi ini adalah alat preliminary design. Final AHU/coil/fan/HEPA/duct/diffuser dan commissioning harus diverifikasi oleh engineer HVAC serta mengacu pada peraturan dan standar yang berlaku pada tanggal proyek.
